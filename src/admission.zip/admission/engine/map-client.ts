import { AdmissionDatastream } from "../types/datastream";
import { FlatAdmissionMatch } from "../types/admission-result";
import { schoolDirectory } from "../data";
import { normalizeTextToken } from "../utils/normalize-school-name";
import { classifyAdmission } from "./classification";
import { evaluateStudentDirectly } from "./matcher";

export interface ClientListInputRow {
  sN?: string | number;
  name: string;
  schoolOfChoice: string;
  sex?: string;
  sheetName?: string;
}

function formatLgaLabel(value?: string): string {
  if (!value) return "N/A";
  return value.replace(/\s+ZONE$/i, "").trim();
}

function formatValue(value?: string): string {
  if (!value || !String(value).trim()) return "N/A";
  return String(value).trim();
}

interface SchoolResolution {
  lga: string;
  schoolName: string;
}

function resolveSchoolNameAndLga(schoolName?: string): SchoolResolution {
  if (!schoolName) return { lga: "N/A", schoolName: "N/A" };

  const normalizedSearch = normalizeTextToken(schoolName);
  if (!normalizedSearch) return { lga: "N/A", schoolName: "N/A" };

  for (const [zoneName, schools] of Object.entries(schoolDirectory)) {
    for (const directorySchool of schools) {
      if (normalizeTextToken(directorySchool) === normalizedSearch) {
        return {
          lga: formatLgaLabel(zoneName),
          schoolName: directorySchool,
        };
      }
    }
  }

  return { lga: "N/A", schoolName: "N/A" };
}

function getSchoolLga(schoolName?: string): string {
  return resolveSchoolNameAndLga(schoolName).lga;
}

function printTable(title: string, rows: Array<Record<string, string | number>>) {
  console.log(`\n${title}`);
  console.table(rows);
}

export function generateAndLogAdmissionReport(
  clientList: ClientListInputRow[],
  datastream: AdmissionDatastream
): FlatAdmissionMatch[] {
  const groupedRows = clientList.reduce<Record<string, ClientListInputRow[]>>((acc, row) => {
    const sheetKey = row.sheetName || "DEFAULT";
    acc[sheetKey] = acc[sheetKey] || [];
    acc[sheetKey].push(row);
    return acc;
  }, {});

  const allMatches: FlatAdmissionMatch[] = [];

  Object.entries(groupedRows).forEach(([sheetName, rows], index) => {
    const finalMatchesList = rows.map((row) => {
      const match = evaluateStudentDirectly(row.name, row.schoolOfChoice, datastream);
      const classified = classifyAdmission(match, datastream);
      return {
        ...classified,
        clientSerialNumber: row.sN,
        clientSex: row.sex,
        sex: classified.sex || row.sex || match.sex,
      } as FlatAdmissionMatch & {
        clientSerialNumber?: string | number;
        clientSex?: string;
        category?: string;
        matchedChoiceLga?: string;
        actualSchoolLga?: string;
        matchedSchoolChoice?: string;
        matchedSchoolName?: string;
      };
    });

    allMatches.push(...finalMatchesList);

    const totalCount = finalMatchesList.length;
    const admittedMatches = finalMatchesList.filter((match) => (match as FlatAdmissionMatch & { category?: string }).category === "ADMITTED");
    const redirectedMatches = finalMatchesList.filter((match) => (match as FlatAdmissionMatch & { category?: string }).category === "REDIRECTED");
    const notAdmittedMatches = finalMatchesList.filter((match) => (match as FlatAdmissionMatch & { category?: string }).category === "NOT_ADMITTED");
    const admittedCount = admittedMatches.length;
    const redirectedCount = redirectedMatches.length;
    const missingCount = notAdmittedMatches.length;

    if (index > 0) {
      console.log("\n");
    }

    console.log("========================================================");
    console.log("ADMISSION REPORT");
    console.log("========================================================");
    console.log(`\nSUMMARY ${sheetName === "DEFAULT" ? "" : sheetName}`.trim());
    console.log(`Total Students : ${totalCount}`);
    console.log(`Admitted       : ${admittedCount}`);
    console.log(`Redirected     : ${redirectedCount}`);
    console.log(`Not Admitted   : ${missingCount}`);

    console.log("\n--------------------------------------------------");
    console.log("ADMITTED");
    console.log("--------------------------------------------------");

    if (admittedMatches.length === 0) {
      console.log("(None)");
    } else {
      const admittedBySchool = admittedMatches.reduce<Record<string, FlatAdmissionMatch[]>>((acc, match) => {
        const schoolName = match.schoolName || "UNKNOWN SCHOOL";
        acc[schoolName] = acc[schoolName] || [];
        acc[schoolName].push(match);
        return acc;
      }, {});

      Object.entries(admittedBySchool).forEach(([schoolName, matches]) => {
        console.log(`\nSchool: ${schoolName}`);
        console.log(`LGA: ${getSchoolLga(schoolName)}`);
        printTable(
          "",
          matches.map((match) => ({
            "S/N": formatValue(String((match as FlatAdmissionMatch & { clientSerialNumber?: string | number }).clientSerialNumber ?? "")),
            "Admission No": formatValue(match.admissionNumber),
            "Full Name": formatValue(match.clientName),
            "Sex": formatValue(match.sex),
          }))
        );
      });
    }

    console.log("\n--------------------------------------------------");
    console.log("REDIRECTED ADMISSION(S)");
    console.log("--------------------------------------------------");

    if (redirectedMatches.length === 0) {
      console.log("(None)");
    } else {
      const redirectedBySchool = redirectedMatches.reduce<Record<string, typeof redirectedMatches>>((acc, match) => {
        const schoolName = match.schoolName || (match as FlatAdmissionMatch & { matchedSchoolName?: string }).matchedSchoolName || "UNKNOWN SCHOOL";
        acc[schoolName] = acc[schoolName] || [];
        acc[schoolName].push(match);
        return acc;
      }, {});

      Object.entries(redirectedBySchool).forEach(([schoolName, matches]) => {
        const firstMatch = matches[0] as FlatAdmissionMatch & { matchedChoiceLga?: string; actualSchoolLga?: string; matchedSchoolName?: string; matchedSchoolChoice?: string };
        console.log(`\nSchool: ${firstMatch.matchedSchoolName || schoolName || "N/A"}`);
        console.log(`LGA: ${firstMatch.matchedChoiceLga || "N/A"}`);
        printTable(
          "",
          matches.map((match) => {
            const choiceDisplay = resolveSchoolNameAndLga((match as FlatAdmissionMatch & { matchedSchoolChoice?: string }).matchedSchoolChoice || match.clientSchoolChoice).schoolName;
            const choiceLga = resolveSchoolNameAndLga((match as FlatAdmissionMatch & { matchedSchoolChoice?: string }).matchedSchoolChoice || match.clientSchoolChoice).lga;

            return {
              "S/N": formatValue(String((match as FlatAdmissionMatch & { clientSerialNumber?: string | number }).clientSerialNumber ?? "")),
              "Admission No": formatValue(match.admissionNumber),
              "Full Name": formatValue(match.clientName),
              "Sex": formatValue(match.sex),
              "School of Choice": formatValue(`${choiceDisplay}, ${choiceLga}`),
            };
          })
        );
      });
    }

    console.log("\n--------------------------------------------------");
    console.log("NOT ADMITTED");
    console.log("--------------------------------------------------");

    if (notAdmittedMatches.length === 0) {
      console.log("(None)");
    } else {
      const notAdmittedBySchool = notAdmittedMatches.reduce<Record<string, typeof notAdmittedMatches>>((acc, match) => {
        const schoolName = (match as FlatAdmissionMatch & { matchedSchoolName?: string }).matchedSchoolName || "UNKNOWN SCHOOL";
        acc[schoolName] = acc[schoolName] || [];
        acc[schoolName].push(match);
        return acc;
      }, {});

      Object.entries(notAdmittedBySchool).forEach(([schoolName, matches]) => {
        const firstMatch = matches[0] as FlatAdmissionMatch & { matchedChoiceLga?: string; matchedSchoolName?: string };
        console.log(`\nSchool of Choice: ${firstMatch.matchedSchoolName || schoolName || "N/A"}`);
        console.log(`LGA: ${firstMatch.matchedChoiceLga || "N/A"}`);
        printTable(
          "",
          matches.map((match) => ({
            "S/N": formatValue(String((match as FlatAdmissionMatch & { clientSerialNumber?: string | number }).clientSerialNumber ?? "")),
            "Full Name": formatValue(match.clientName),
            "Sex": formatValue((match as FlatAdmissionMatch & { clientSex?: string }).clientSex || match.sex),

          }))
        );
      });
    }

    console.log("\n========================================================\n");
  });

  return allMatches;
}
